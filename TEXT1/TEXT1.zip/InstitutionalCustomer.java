import java.util.ArrayList;
import java.util.Iterator;

/**
 * define InstitutionalCustomer and implements Customer and Iterable.
 * @author qijun xie
 * @version 1.0.0
 */
public class InstitutionalCustomer implements Customer, Iterable<Contact> {

    private String customerId ;

    private ArrayList <Contact> contacts ;

    /**
     * class constructors
     * @param initialCustomerId
     * @param contacts
     */
    InstitutionalCustomer(String initialCustomerId , ArrayList<Contact> contacts) {

        this.customerId = initialCustomerId ;

        this.contacts = contacts;
    }

    /**
     *  Class initialization
     */
    InstitutionalCustomer() {};

    /**
     * Obtain the Iterator of the Contact.
     * @return the Iterator of the Contact
     */
    public Iterator<Contact> iterator() {

        return this.contacts.iterator() ;
    }

    /**
     * get the CustomerId of the class
     * @return the CustomerId of the class
     */
    public String getCustomerId() {

        return this.customerId;
    }

    /**
     * get the specified Contact by the contact's name
     * @param name
     * @return the specified Contact by the contact's name
     */
    public Contact getContact(String name) {

        for (Contact contact : contacts) {

            if (contact.getName().equals(name)) {

                return contact;
            }
        }

        return null ;
    }

    /**
     * add the contact into the contacts .
     * @param contact
     */
    public void addContact(Contact contact) {

        contacts.add(contact) ;
    }
}
