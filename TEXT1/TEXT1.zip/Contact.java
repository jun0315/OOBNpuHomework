/**
 * define the class Contact and extend Person
 * @qijun xie
 * @version 1.0.0
 */
public class Contact extends Person {

    private String workTelephone ;

    private String jobPosition ;

    /**
     * class constructors
     * @param initialName
     * @param initialHomeTelephone
     * @param initialEmail
     * @param initialWorkTelephone
     * @param initialJobPosition
     */
    public Contact(String initialName, String initialHomeTelephone,
                   String initialEmail,String initialWorkTelephone ,
                   String initialJobPosition) {

        super(initialName , initialHomeTelephone , initialEmail);

        this.jobPosition = initialJobPosition ;

        this.workTelephone = initialWorkTelephone ;
    }

    /**
     * get the Telephone of the class
     * @return the Telephone of the class
     */
    public String getWorkTelephone() {

        return this.workTelephone;
    }
    /**
     * get the jobPosition of the class
     * @return the jobPosition of the class
     */
    public String getJobPosition() {

        return this.jobPosition;
    }
    /**
     * Returns the string representation of this Contact in the following
     * @return the string representation of this Contact in the following
     */
    public String toString() {

        return super.toString() + "_" + this.getWorkTelephone() + "_" + this.getJobPosition() ;
    }
}
