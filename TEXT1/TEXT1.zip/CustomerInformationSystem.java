import java.util.ArrayList;
/**
 * define the class CustomerInformationSystem
 * @qijun xie
 * @version 1.0.0
 */
public class CustomerInformationSystem {

    private ArrayList<Customer> customers ;

    /**
     * class constructors
     */
    CustomerInformationSystem() {

        customers = new ArrayList<Customer>();
    }

    /**
     * add the specified customer into the ArrayList
     * @param customer
     */
    public void addCustomer(Customer customer) {

        int flag = 0 ;

        for (Customer customer1 : customers ) {

            if (customer1.getCustomerId().equals(customer.getCustomerId())) {

                flag = 1 ;

                break;

            }
        }

        if ( flag == 0 ) {

            customers.add(customer);
        }
    }

    /**
     *Obtain the specified Customer through the customerId
     * @param customerId
     * @return the specified Customer
     */
    public Customer getCustomer(String customerId) {

        for ( Customer customer : customers ) {

            if ( customer.getCustomerId().equals(customerId)) {

                return customer ;
            }
        }

        return null ;
    }

    /**
     * if the customerId of  the customer was the InstitutionalCustomer ,then
     * add the contact into the customer and return true else return false.
     * @param customerId
     * @param contact
     * @return the <code>true</code> or <code>false</code> .
     */
    public boolean addContact (String customerId , Contact contact) {

        for (Customer customer : customers) {

            if (customer.getCustomerId().equals(customerId)) {

                if (customer instanceof IndividualCustomer) {

                    return false ;
                }

                else {

                    ((InstitutionalCustomer)customer).addContact(contact) ;

                    return true ;
                }
            }
        }

        return false ;
    }
}
